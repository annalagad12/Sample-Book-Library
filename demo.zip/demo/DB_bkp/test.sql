-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 14, 2019 at 05:50 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_master`
--

CREATE TABLE `book_master` (
  `book_id` int(10) UNSIGNED NOT NULL COMMENT 'International Standard Book Number (ISBN)',
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `edition` int(11) NOT NULL,
  `publication` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `price` decimal(10,0) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book_master`
--

INSERT INTO `book_master` (`book_id`, `title`, `author`, `edition`, `publication`, `quantity`, `price`, `created_date`, `updated_date`) VALUES
(1, 'Book Keeping & Accountancy	', 'Anna Lagad', 2009, 'Nirali Publication pvt.ltd', 10, '120', '2019-10-13 20:02:02', '2019-10-13 20:02:02'),
(2, 'Economics', 'Anna lagad', 2005, 'Navneet', 10, '230', '2019-10-13 20:02:51', '2019-10-13 20:02:51'),
(3, 'Math', 'Parag Sane', 2007, 'Nirali Publications', 10, '300', '2019-10-13 20:03:32', '2019-10-13 20:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `customer_book_map`
--

CREATE TABLE `customer_book_map` (
  `map_id` int(10) UNSIGNED NOT NULL,
  `customer_id` int(10) UNSIGNED NOT NULL,
  `book_id` int(10) UNSIGNED NOT NULL,
  `issue_date` datetime NOT NULL,
  `return_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `customer_master`
--

CREATE TABLE `customer_master` (
  `customer_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `registration_date` datetime NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_master`
--

INSERT INTO `customer_master` (`customer_id`, `name`, `address`, `registration_date`, `status`) VALUES
(1, 'Swarup Lagad', 'Sutarwadi, Pashan, Pune-411021', '2019-10-01 20:04:54', 'active'),
(2, 'Sushant Bhadule', 'Sahil Vignesh residency, wakad, pune-21', '2019-10-09 00:00:00', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_master`
--
ALTER TABLE `book_master`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `customer_book_map`
--
ALTER TABLE `customer_book_map`
  ADD PRIMARY KEY (`map_id`);

--
-- Indexes for table `customer_master`
--
ALTER TABLE `customer_master`
  ADD PRIMARY KEY (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_master`
--
ALTER TABLE `book_master`
  MODIFY `book_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'International Standard Book Number (ISBN)', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customer_book_map`
--
ALTER TABLE `customer_book_map`
  MODIFY `map_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_master`
--
ALTER TABLE `customer_master`
  MODIFY `customer_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
