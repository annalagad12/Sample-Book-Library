<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Book extends CI_Controller {

	/**
	 * Data object with require data to be pass to view
	 *
	 * @var $data
	 */
	private $data;

	public function __construct()
	{
		parent::__construct();
		// Load require model
		$this->load->model('book_model');
		//initialize variable with default value
		$this->data = null;
	}

	/**
	 * Default method which will load default view containing list of all books available in system
	 */
	public function index()
	{
		$this->data['books'] = $this->book_model->listBook();
		$this->data['customers'] = $this->book_model->listCustomer();
		$this->load->view('list_book_view', $this->data);
	}

	/**
	 * This method help to load updated view after issued a book to end user with appropriate message
	 */
	public function issueBook()
	{
		$customer_id = $this->input->post('customer_id');
		$book_id = $this->input->post('book_id');
		if($customer_id > 0)
		{
			$is_already_issued = $this->book_model->isBookAlreadyIssued($book_id, $customer_id);
			if(empty($is_already_issued)===true)
			{
				$input_data = array(
					'customer_id' => $customer_id,
					'book_id' => $book_id,
					'issue_date' => date('Y-m-d h:i:s')
				);
				$result = $this->book_model->issueBook($input_data);
				if($result)
				{
					$this->data['user_message'] = "Book successfully issued";
				}
				else
				{
					$this->data['user_message'] = "Something went wrong Please try agian!";
				}
			}
			else
			{
				$this->data['user_message'] = "Book already issued to same customer";
			}
		}
		else
		{
			$this->data['user_message'] = "Please select customer to issue book";
		}
		$this->data['customers'] = $this->book_model->listCustomer();
		$this->data['books'] = $this->book_model->listBook();
		$this->load->view('list_view', $this->data);
	}

	/**
	 * This method help to load updated view after return a book from end user with appropriate user message
	 */
	public function returnBook()
	{
		$customer_id = $this->input->post('customer_id');
		$book_id = $this->input->post('book_id');
		if($customer_id > 0)
		{
			$is_book_issued = $this->book_model->isBookAlreadyIssued($book_id, $customer_id);
			if($is_book_issued)
			{
				$input_data = array(
					'customer_id' => $customer_id,
					'book_id' => $book_id
				);
				$result = $this->book_model->returnBook($input_data);
				if($result)
				{
					$this->data['user_message'] = "Book successfully returned.";
				}
				else
				{
					$this->data['user_message'] = "Something went wrong Please try agian!";
				}
		   }
		   else
		   {
			$this->data['user_message'] = "No book found with selected customer";
		   }
		}
		else
		{
			$this->data['user_message'] = "Please select customer";
		}
		$this->data['customers'] = $this->book_model->listCustomer();
		$this->data['books'] = $this->book_model->listBook();
		$this->load->view('list_view', $this->data);
	}

	/**
	 * This method help to load updated view with book availability status with appropriate user message
	 */
	public function isBookAvailable()
	{ 
		$book_id = $this->input->post('book_id');
		$quantity = $this->book_model->isBookAvailable($book_id);
		if($quantity > 0)
		{
			$this->data['user_message'] = "Total number of books available = $quantity ";
		}
		else
		{
			$this->data['user_message'] = "Sorry! Book is not available at this movement";
		}
		$this->data['books'] = $this->book_model->listBook();
		$this->data['customers'] = $this->book_model->listCustomer();
		$this->load->view('list_view', $this->data);
	}

}
