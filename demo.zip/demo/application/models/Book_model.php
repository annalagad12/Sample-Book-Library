<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Model Class containing all the Business Logic for handling book related activity.
 * @author Anna Lagad
 * @version 1.00
 *
 */
class Book_model extends CI_Model {

	public function __construct()
	{
		// Call parent class constructor
		parent::__construct();
	}

	/**
	 * @author Anna Lagad
	 * @desc Function used to get list of all book from DB
	 * @return bool	/ object
	 */
	public function listBook()
	{
		try
		{
			$this->db->select('book_id, title, author, edition, publication');
			$query = $this->db->get(BOOK_MASTER);
			if ($query->num_rows() > 0)
			{
				return $query->result_array();
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc Function used to get list of all customer from DB
	 * @return bool	/ object
	 */
	public function listCustomer()
	{
		try
		{
			$this->db->select('customer_id, name');
			$query = $this->db->get(CUSTOMER_MASTER);
			if ($query->num_rows() > 0)
			{
				return $query->result_array();
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc Function used to store issued bok details into DB
	 * @param (array) $input_data an array of issued book details
	 * @return bool
	 */
	public function issueBook($input_data=null)
	{
		try
		{
			if(empty($input_data)===false)
			{
				$this->db->insert(CUSTOMER_BOOK_MAP, $input_data);
				if($this->db->affected_rows() > 0)
				{
					return $this->updateStock($input_data['book_id']);
				}
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc Function used to update status and quantity of book into DB
	 * @param (array) $input_data
	 * @return bool
	 */
	public function returnBook($input_data=null)
	{
		try
		{
			if(empty($input_data)===false)
			{
				$this->db->set('return_date', date('Y-m-d h:i:s'));
				$this->db->where($input_data);
				$this->db->update(CUSTOMER_BOOK_MAP, $input_data);
				if($this->db->affected_rows() > 0)
				{
					return $this->updateStock($input_data['book_id'], 'plusone');
				}
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc function used to check whether book is available on not based on given book id
	 * @param (integer) $book_id
	 * @return bool
	 */
	public function isBookAvailable($book_id = null)
	{
		try
		{
			if(empty($book_id)===false)
			{
				$this->db->select('quantity');
				$this->db->where('book_id', $book_id);
				$query = $this->db->get(BOOK_MASTER);
				if ($query->num_rows() > 0)
				{
					return $query->row('quantity');
				}
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc function used to check whether book is already issued to the same customer
	 * @param (integer) $book_id
	 * @param (integer) $customer_id
	 * @return bool
	 */
	public function isBookAlreadyIssued($book_id = null, $customer_id = null)
	{
		try
		{
			if(empty($book_id)===false && empty($customer_id)===false)
			{
				$this->db->select('map_id');
				$this->db->where('book_id', $book_id);
				$this->db->where('customer_id', $customer_id);
				$this->db->where('return_date IS NULL');
				$query = $this->db->get(CUSTOMER_BOOK_MAP);
				return $query->num_rows() > 0;
			}
			return false;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

	/**
	 * @author Anna Lagad
	 * @desc function help to update book stock on every successfull book issue to customer
	 * @param (integer) $book_id
	 * @param (integer) $customer_id
	 * @return bool
	 */
	private function updateStock($book_id = null, $quantity = null)
	{
		try
		{
			if($quantity == 'plusone')
			{
				$this->db->set('quantity','quantity +'. 1, false);
			}
			else
			{
				$this->db->set('quantity','quantity -'. 1, false);
			}
			
			$this->db->where('book_id', $book_id);
			$this->db->update(BOOK_MASTER);
			return $this->db->affected_rows() > 0;
		}
		catch(Exception $e)
		{
			echo "Something went wrong: ". $e->getMessage();
		}
	}

}
