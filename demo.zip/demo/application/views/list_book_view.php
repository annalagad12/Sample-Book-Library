<!DOCTYPE HTML>
<html>
<script> var SITEURL = '<?php echo base_url();?>'</script>
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/book.js'); ?>"></script>
<body bgcolor="87ceeb">
<h2 align="center">Books Managment System</h2>
<br>
<div id="tbl_book"><?php include('list_view.php');?></div>
</body>
</html>

