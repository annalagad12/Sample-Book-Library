<span><?php echo isset($user_message)?$user_message:'';?></span>
<table border="2" align="center" cellpadding="5" cellspacing="5">
	<tr>
		<th> Book ID </th>
		<th> Title </th>
		<th> Author </th>
		<th> Edition </th>
		<th> Publication </th>
		<th> Customer </th>
		<th> Action </th>
	</tr>
	<?php 
	if(empty($books) === false) {  
		foreach($books as $book) {
	?>
	<tr>
		<td><?=$book['book_id']?></td>
		<td><?=$book['title']?></td>
		<td><?=$book['author']?></td>
		<td><?=$book['edition']?></td>
		<td><?=$book['publication']?></td>
		<td>
			<select id="customer_id_<?=$book['book_id']?>">
			    <option value="0">--Select Customer--</option>
				<?php 
				if(empty($customers) === false) {  
					foreach($customers as $customer) {
				?>
				<option value="<?=$customer['customer_id']?>"><?=$customer['name']?></option>
				<?php 
					}
				} 
				?>
			</select>
		</td>
		<td>
			<button onclick="is_available(<?=$book['book_id']?>);">Is available</button>
			<button onclick="issue_book(<?=$book['book_id']?>);">Issue Book</button>
			<button onclick="return_book(<?=$book['book_id']?>);">Return Book</button>

		</td>
	</tr>
<?php 
	}
} 
?>
</table>
