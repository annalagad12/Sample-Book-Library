
function is_available(bookid)
{ 
	$.post(SITEURL+"index.php/book/isBookAvailable",{'book_id': bookid}, function(data){
      $("#tbl_book").html(data);
	});
}

function issue_book(bookid)
{
	customer_id = $('#customer_id_'+bookid).val();
	$.post(SITEURL+"index.php/book/issueBook",{'book_id': bookid,'customer_id':customer_id}, function(data){
		$("#tbl_book").html(data);
	  });
}

function return_book(bookid)
{
	customer_id = $('#customer_id_'+bookid).val();
	$.post(SITEURL+"index.php/book/returnBook",{'book_id': bookid, 'customer_id':customer_id}, function(data){
		$("#tbl_book").html(data);
	  });
}